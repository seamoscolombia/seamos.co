require 'test_helper'

class GlobalTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
