require 'test_helper'

class MunicipioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
