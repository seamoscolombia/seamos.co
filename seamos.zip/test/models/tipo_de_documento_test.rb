require 'test_helper'

class TipoDeDocumentoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
