require 'test_helper'

class DepartamentoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
