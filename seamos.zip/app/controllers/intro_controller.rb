class IntroController < ApplicationController
  def inicio
  end
end
