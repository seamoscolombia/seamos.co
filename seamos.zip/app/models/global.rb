class Global < ApplicationRecord
end
