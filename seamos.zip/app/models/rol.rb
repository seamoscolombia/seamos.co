class Rol < ApplicationRecord
end
