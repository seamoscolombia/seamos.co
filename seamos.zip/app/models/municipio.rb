class Municipio < ApplicationRecord
  belongs_to :departamento
end
